namespace UnityEngine.SettingsManagement.EditorTests
{
	public class SettingsTestBase
	{
		public const string k_PackageName = "com.unity.settings-manager.tests";
	}
}
